csxgistaddpoint halaudio 0 halaudio_adc inject sync 0 0 0 /tmp/16k_2k.pcm repeat 0 
q

