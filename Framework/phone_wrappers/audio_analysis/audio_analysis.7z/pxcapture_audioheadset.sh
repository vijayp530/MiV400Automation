csxgistaddpoint halaudio 2 halaudio_dac capture sync /tmp/headset_capture.pcm truncate 0 0 0 0
q
    