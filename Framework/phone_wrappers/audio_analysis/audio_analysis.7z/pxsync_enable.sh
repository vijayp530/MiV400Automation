ecenable handset disable
csxgistsyncenable halaudio
q

