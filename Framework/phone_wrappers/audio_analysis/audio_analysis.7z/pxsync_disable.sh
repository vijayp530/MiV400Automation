ecenable handset enable
csxgistsyncdisable halaudio 
q
