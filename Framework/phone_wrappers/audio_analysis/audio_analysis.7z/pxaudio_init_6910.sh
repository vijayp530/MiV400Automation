/sbin/modprobe csx_gist_drv.ko
/sbin/modprobe csx_halaudio
