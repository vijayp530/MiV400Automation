csxgistaddpoint halaudio 1 halaudio_adc capture sync /tmp/speaker_capture.pcm truncate 0 0 0 0
q
