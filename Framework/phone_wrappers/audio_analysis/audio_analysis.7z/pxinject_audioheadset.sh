csxgistaddpoint halaudio 2 halaudio_adc inject sync 0 0 0 /tmp/16k_500.pcm repeat 0
q
 
