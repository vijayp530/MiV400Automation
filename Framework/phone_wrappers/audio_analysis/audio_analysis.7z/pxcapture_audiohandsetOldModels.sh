csxgistaddpoint halaudio 0 halaudio_dac capture sync /tmp/handset_capture.pcm truncate 0 0 0 0
q
