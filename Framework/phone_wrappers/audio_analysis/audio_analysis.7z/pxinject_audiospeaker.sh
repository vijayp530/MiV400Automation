csxgistaddpoint halaudio 1 halaudio_adc_slot0 inject sync 0 0 0 /tmp/16k_3k.pcm repeat 0
 
q

