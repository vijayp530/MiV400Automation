csxgistaddpoint halaudio 0 halaudio_dac_slot0 capture sync /tmp/handset_capture.pcm truncate 0 0 0 0
q
