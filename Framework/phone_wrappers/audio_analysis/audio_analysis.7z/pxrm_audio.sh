csxgistsyncdisable halaudio 
csxgistremallpoints
q
