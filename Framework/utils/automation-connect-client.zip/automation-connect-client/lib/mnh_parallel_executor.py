from threading import  Thread
#import multiprocessing
import ManhattanComponent
import time
from robot.api.logger import console
obj_list = []
lthreads1 = []
lthreads2 = []
lthreads3 = []
lthreads4 = []

def parallel_launch(dic, obj):    
    obj.launch_client(dic)    
    
def parallel_login(user, obj):    
    obj.client_login(**user)
    
def parallel_logout(obj):
    obj.close_browser()

def parallel_hookup(obj):
    obj.end_voicemail_call()    
    
def parallel_select_desk_phone(obj):
    obj.select_phone_type(phone_type ='desk_phone', soft= '')

def parallel_select_soft_phone(obj):
    obj.select_phone_type(phone_type ='soft_phone', soft= 'yes')

def parallel_close_conference(obj):
    obj.close_conference_entry(nofail=1)


def launch_login(**params):
    #import sys;import pdb;pdb.Pdb(stdout=sys.__stdout__ ).set_trace()
    global obj_list
    client1 = ManhattanComponent.ManhattanComponent("parallel")
    obj_list.append(client1)
    client2 = ManhattanComponent.ManhattanComponent("parallel")
    obj_list.append(client2)
    client3 = ManhattanComponent.ManhattanComponent("parallel")
    obj_list.append(client3)
    client4 = ManhattanComponent.ManhattanComponent("parallel")
    obj_list.append(client4)    
    launch(**params)
    login(**params)
    # if params["soft_phone"]:
    #     console("soft_phone")
    #     post_select_softphone(**params)
    #end_calls(**params)
    #close_conference_login(**params)
    #select_deskphone(**params)
    #console(obj_list)
    return obj_list

def close_applications(params):
    #close_conference_logout(params)
    # if params["end_call"]:
    #     console("end_call")
    #     post_end_calls(params)
    # if params["end_conf"]:
    #     console("end_conf")
    #     post_close_conference(params)
    # if params["desk_phone"]:
    #     console("desk_phone")
    #     post_select_deskphone(**params)
    close_client(params)

def launch(**params): 
    global lthreads1
    dicts = [
    {'server':'localhost', 'component_type':'manhattancomponent', 'port':'4444', 'browserName':'chrome', 'aut':'connect_client', 'isDevScript':'true'}
    ,{'server':'localhost', 'component_type':'manhattancomponent', 'port':'5555', 'browserName':'chrome', 'aut':'connect_client', 'isDevScript':'true'}
    ,{'server':'localhost', 'component_type':'manhattancomponent', 'port':'6666', 'browserName':'chrome', 'aut':'connect_client', 'isDevScript':'true'}
    ,{'server':'localhost', 'component_type':'manhattancomponent', 'port':'7777', 'browserName':'chrome', 'aut':'connect_client', 'isDevScript':'true'}
    ]   
    
    import Queue
    q = Queue.Queue()
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_launch, args=[dicts[i], obj_list[i]])
        t.start()
        lthreads1.append(t)
    
    for t in lthreads1:
        t.join()
    
    
def login(**params):
    global lthreads2
    users = [{'username':params['user1'].client_id, 'password':params['user1'].client_password, 'server_address':params['user1'].server}
    ,{'username':params['user2'].client_id, 'password':params['user2'].client_password, 'server_address':params['user2'].server}
    ,{'username':params['user3'].client_id, 'password':params['user3'].client_password, 'server_address':params['user3'].server}
    ,{'username':params['user4'].client_id, 'password':params['user4'].client_password, 'server_address':params['user4'].server}]

    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_login, args=[users[i], obj_list[i]])
        t.start()
        lthreads2.append(t)
    
    for t in lthreads2:
        t.join()

def end_calls(**params):
    global lthreads4
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_hookup, args=[obj_list[i]])
        t.start()
        lthreads4.append(t)
    
    for t in lthreads4:
        t.join()

def select_deskphone(**params):
    global lthreads4
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_select_desk_phone, args=[obj_list[i]])
        t.start()
        lthreads4.append(t)
    
    for t in lthreads4:
        t.join()
    
def close_client(params): 
    global lthreads3
    for i in range(int(params)):
        t = Thread(target=parallel_logout, args=[obj_list[i]])
        t.start()
        lthreads3.append(t)
    
    for t in lthreads3:
        t.join()

def close_conference_login(**params):
    global lthreads4
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_close_conference, args=[obj_list[i]])
        t.start()
        lthreads4.append(t)
    
    for t in lthreads4:
        t.join()

def post_close_conference(**params):
    global lthreads4
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_close_conference, args=[obj_list[i]])
        t.start()
        lthreads4.append(t)
    
    for t in lthreads4:
        t.join()

def post_end_calls(**params): 
    global lthreads4
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_hookup, args=[obj_list[i]])
        t.start()
        lthreads4.append(t)
    
    for t in lthreads4:
        t.join()

def post_select_deskphone(**params): 
    global lthreads4
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_select_desk_phone, args=[obj_list[i]])
        t.start()
        lthreads4.append(t)
    
    for t in lthreads4:
        t.join()

def post_select_softphone(**params): 
    global lthreads4
    for i in range(int(params['client_count'])):
        t = Thread(target=parallel_select_soft_phone, args=[obj_list[i]])
        t.start()
        lthreads4.append(t)
    
    for t in lthreads4:
        t.join()
