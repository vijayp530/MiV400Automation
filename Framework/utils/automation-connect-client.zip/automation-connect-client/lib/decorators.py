def softfail_in_teardown(func):
    def func_wrapper(*args, **kwargs):
        try:
            res = func(*args,**kwargs)
            return res
        except Exception as ex:
            from robot.libraries.BuiltIn import BuiltIn
            if BuiltIn()._context.in_test_teardown:
                pass
            else:
                raise ex
    return func_wrapper