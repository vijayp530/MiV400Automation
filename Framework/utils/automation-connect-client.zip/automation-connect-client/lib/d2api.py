import sys
import requests
import urllib, base64
import re
import json
from argparse import ArgumentParser 

class D2API():
    def __init__(self, ip,  username, password):
        #print "Initializing session for request object!\n"
        self.client = requests.session()
        #print "Done!\n"

        if ":" in ip:
            ip_split = ip.split(":")
            self.ip = ip_split[0]
            self.pno = ip_split[-1]
        else:
            self.ip = ip
            self.pno = '5478'
        
        res = self.create_connection(self.ip, self.pno, username, password)

    def create_connection(self, hqIp, pno, username, password):
        """
        """
        # Retrieve the CSRF token first
        LOGIN_URL = 'http://'+hqIp+':'+pno+'/director/login'
        
        #print "Trying to set cookie by hitting login url with GET!\n"
        self.client.get(LOGIN_URL)  # sets cookie
        d2_cookie = self.client.cookies['_director2_session']
        #print "Done!\n"
        
        ###print d2_cookie
        csrftoken = re.match('(.+)--',d2_cookie).group(1)
        ###print csrftoken
        csrftoken = urllib.unquote(d2_cookie)
        ###print csrftoken
        csrftoken = base64.b64decode(csrftoken)
        # csrftoken = r'{I"session_id:EFI"%8cb0cc7d1645b236e217e3e35826b9dd; TI"abc; F{:    hostI"localhost; FI"_csrf_token; FI"1lC0TGuAk9D6C0f68Fy9T8UsQ0RaQg9uXiTRnPra+iLE=; F'
        #print "CSRF Token after base64 decode:" + csrftoken
        # csrftoken = re.match('.*_csrf_token.*1(.*=).*', csrftoken).group(1)
        csrftoken = re.match('.*_csrf_token.*\"1(.*=).*', csrftoken).group(1)
        #print "CSRF token after extracting using regex:" + csrftoken
        self.csrftoken = csrftoken
        # 'admin@mt.com', 'changeme'
        
        #print "Trying to login using credentials and CSRF token by hitting login url with POST!\n"
        res = self.client.post(LOGIN_URL,data={"user_session[login_name]": username, "user_session[login_password]": password, "authenticity_token": self.csrftoken})
        #print "Done!"
        return res
    
    def delete_telephone(self, entry_id):
        DELETE_TELE_API = "http://" + self.ip + ":" + self.pno + "/director/ip_phones/" + entry_id + ".json"
        res = self.client.delete(DELETE_TELE_API)
        return res
    
    def switch_tenant(self, tid):
        SWITCH_TENANT_API = "http://" + self.ip + ":" + self.pno + "/director/global_data/cas_session_params?TenantID=" + tid
        res = self.client.get(SWITCH_TENANT_API)
        print "Switch tenant api called: {}, {}".format(res.status_code, res.text)
    
    def get_telephone_list(self, tid):
        TELEPHONE_LIST_API = 'http://10.32.129.90:5478/director/ip_phones/list?_filter_tenant_id='+ tid +'&_filter_system_tenant_id='+ tid
        # TELEPHONE_LIST_API = "http://10.32.129.90:5478/director/ip_phones/list?_filter_tenant_id=12976&_filter_system_tenant_id=12976"
        result = self.client.get(TELEPHONE_LIST_API)
        return result
    
    def fetch_acode_list(self):
        ACODE_LIST_API = 'http://'+self.ip+':'+self.pno+'/director/account_codes/list'
        # _search=False&nd=1531829027178&rows=250&page=1&sidx=&sord=asc&_filter_tenant_id=1&_filter_system_tenant_id=1&id=15
        result = self.client.get(ACODE_LIST_API)
        return result

    def add_acode(self, acode_name, acode_number):
        ##print "Trying to add account code: {} and account code name: {}\n\n".format(acode,acode_name) 
        ##print "Headers: {}\n\n".format(self.client.headers)
        ##print "Cookies: {}\n\n".format(self.client.cookies)

        ACODE_NEW_URL = 'http://'+self.ip+':'+self.pno+'/director/account_codes/new.json?TenantID=1'
        res = self.client.get(ACODE_NEW_URL)
        #print "\n\nResult from hitting new.json with GET:{}\n".format(res.text)

        acode_req = res.json()

        #print "\n\n JSON RESOPNSE GOT FROM SERVER: {}\n\n".format(acode_req)
        
        print "Trying to add: {}:{}\n\n".format(acode_name, acode_number)

        acode_req['account_code']['AccountCodeInput'] = acode_number
        acode_req['account_code']['AccountName'] = acode_name

        #print "\nAcount code json after editing: {}\n".format(acode_req)

        ACODE_ADD_URL = 'http://'+self.ip+':'+self.pno+'/director/account_codes.json'
        #print "Account code add api url: {}\n\n".format(ACODE_ADD_URL)

        HEADER = {'X-CSRF-Token': self.csrftoken, 'Referer': "http://10.197.126.20:5478/director/"}

        #print "\n\nHEADER TO BE SENT WITH REQUEST: {}".format(HEADER)

        result = self.client.post(url=ACODE_ADD_URL, json=acode_req , headers=HEADER)
         # Referer: "http://10.197.126.20:5478/director/"
        #print "Account code add response:{}\n Response Header:".format(result)
        return result

    def add_bulk_acode(self, count):
        for i in xrange(count):
            acode_name = "acode{}".format(i)
            acode_number = str(10001 + i) 
            # print acode_number
            self.add_acode(acode_name, acode_number)


    def delete_all_acode(self):
        
        res = self.fetch_acode_list()
        if res.text!='':
            res = json.loads(res.text)
        else:
            return None
        #print res["rows"]
        id_list = [elems["id"] for elems in res["rows"]]
        print id_list
        return self.delete_acode(id_list)
        

    def delete_acode(self, id_list):
        ##print "Trying to add account code: {} and account code name: {}\n\n".format(acode,acode_name) 
        ##print "Headers: {}\n\n".format(self.client.headers)
        ##print "Cookies: {}\n\n".format(self.client.cookies)

        delete_id_string = ''

        for id in id_list:
            print "Adding {}, ".format(id)
            delete_id_string = delete_id_string + id.__str__() + ','
        delete_id_string = delete_id_string[:-1] + '.'
        delete_id_string += 'json'

        print "Query string formed: {}\n\n".format(delete_id_string) 
        
        ACODE_DELETE_URL = 'http://'+self.ip+':'+self.pno+'/director/account_codes/' + delete_id_string

        HEADER = {'X-CSRF-Token': self.csrftoken, 'Referer': 'http://'+self.ip+':'+self.pno+'/director/'}
        
        res = self.client.delete(url=ACODE_DELETE_URL, headers=HEADER)
        print res
        return res

    def delete_softphones(self, tid, macids):
        res = self.get_telephone_list(tid)
        del_res = None
        if res:
            res = res.json()
            for i in res['rows']:
                if i:
                    if not i['cell'][5] and i['cell'][3] in macids :
                        entry_id = i['id']
                        del_res = self.delete_telephone(str(entry_id))
                        print "null user deleted with mac " +str(i['cell'][3]) 
        return del_res


if __name__ == "__main__":
    d2 = D2API("10.32.129.90", "admintest@qa.shoretel.com", "Shoreadmin1#")
    res = None
    '''
    # 13188: TWI -SCO Feature Test
    # 12976: Barbara-TeamworkForWeb
    '''
    #tid1 = "13188"
    tid2 = "12976"
    #res = d2.delete_softphones(tid1, ['maha1 auto'])
    res = d2.delete_softphones(tid2, ['826C1EE8E927'])