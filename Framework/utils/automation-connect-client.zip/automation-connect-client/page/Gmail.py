"""Module for execution of common portal functionalities such as login, log out, account switch etc
   File: CommonFunctionality.py
   Author: Kiran Prajapati
"""
import os
import glob
import sys
import time
import autoit
import datetime
from datetime import datetime
import re
from robot.libraries.BuiltIn import BuiltIn

#For console logs while executing ROBOT scripts
from robot.api.logger import console
#TODO move path dependency to stafenv.py and import here
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__))))
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(__file__)), "utils"))

import selenium
import imaplib
import smtplib
import email
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
import selenium_wrappers
from mapMgr import mapMgr
from log import log
from page_variables import *
from robot.api.logger import console
from imaplib import IMAP4

ORG_EMAIL   = "@gmail.com"
FROM_EMAIL  = "dummyuser00227" + ORG_EMAIL
FROM_PWD    = "Abc123!1"
SMTP_SERVER = "imap.gmail.com"
SMTP_PORT   = 993

mapMgr.create_maplist("TeamworkComponent")
mapDict = mapMgr.getMapDict()
class Gmail(object):

    def __init__(self, browser):
        self._browser = browser
        self.action_ele = selenium_wrappers.WebElementAction(self._browser)
        self.query_ele  = selenium_wrappers.QueryElement(self._browser)
        self.assert_ele = selenium_wrappers.AssertElement(self._browser)

    def get_gmail_access_code(self, gmail_params):
        time.sleep(5)       #to load the latest content of mail data
        mail = imaplib.IMAP4_SSL('imap.gmail.com')
        mail_id = gmail_params['gmail_id']
        mail_pwd = gmail_params['gmail_pwd']
        mail.login(mail_id,mail_pwd)
        mail.select('inbox')

        result, data = mail.search(None, '(FROM "no-reply@mitel.io" SUBJECT "Forgot Password")')
        ids = data[0]
        id_list = ids.split()
        latest = id_list[-1]

        result, data = mail.fetch(latest, "(RFC822)")
        raw_email = data[0][1]

        msg = email.message_from_string(data[0][1])
        body = ''
        for part in msg.walk():
          if part.get_content_type() == "text/plain":
            body = part.get_payload()
        msg_decoded = ''.join(body.strip().split())
        
        
        for part in msg_decoded.split('.'):
          if 'Seeyousoon' in part:
            code = part.split('Seeyousoon')[0]
        
        raw_email = raw_email.replace('\n', '').replace('\r','').replace('3D','')
        acode_userId =  raw_email.split('accountId=')[1].split('"')[0]
        acode = acode_userId.split('&')[0].replace('=','')
        userId = acode_userId.split('&')[1]
        
        final_mail = "https://auth.dev.mitel.io/setpassword?email="+ mail_id + "%26code%3D" + code + "%26accountId%3D" + acode + "&" + userId
        
        console("code:"+code)
        
        if 'access_code' in gmail_params.keys():
            return code
            
        if 'access_url' in gmail_params.keys():
            return final_mail
                