## -- Common Variables used for Tww Automation-- ##

autoit_notepad_title = "Untitled - Notepad"
autoit_mitel_title = "Mitel Teamwork - Google Chrome"
autoit_mitel_class = "Chrome_RenderWidgetHostHWND1"
autoit_chrome_blank_page = "data:, - Google Chrome"

autoit_ulp_mitel_title = "Mitel - Google Chrome"
autoit_zoom_meeting_title = "Post Attendee - Zoom - Google Chrome"
