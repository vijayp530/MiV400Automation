## Module: Login
## File name: Login.py
## Description: This class contains the common operations like login,logout etc
##
##  -----------------------------------------------------------------------
##  Modification log:
##
##  Date        Engineer              Description
##  ---------   ---------      -----------------------
## 18 AUG 2014  Jahnavi-844             Initial Version
###############################################################################
# Python Modules
import sys
import time
import traceback
from robot.libraries.BuiltIn import BuiltIn
from log import log
from selenium_wrappers import WebElementAction
from selenium_wrappers import QueryElement
from selenium_wrappers import AssertElement
from page_variables import *
from robot.api.logger import console
import autoit

class CommonFunctionalitymnh:
    def __init__(self, browser):
        self._browser = browser
        self.webAction = WebElementAction(self._browser)
        self.assertElement = AssertElement(self._browser)
        self.queryElement = QueryElement(self._browser)

    def first_time_user_login(self, hqIP):
        '''
        first_time_user_login() - when user login to MHClient has to give server IP
        parameter: choice
        ex: choice==yes means entering server and press login button
            choice==no 
        '''
        try:
            self.webAction.input_text("Login_Server_text", hqIP)
            # self.webAction.click_element("Login_Login_Button_server")
            time.sleep(5)
            # print("clicked login button")
            log.mjLog.LogReporter("CommonFunctionality", "info",
                                  "first_time_user_login - Successfully entered HQ Server IP Address")
        except:
            log.mjLog.LogReporter("CommonFunctionality", "info",
                                  "first_time_user_login - error while entering HQ Server IP Address" + str(
                                      sys.exc_info()))
            raise

    def login_ctrlf12(self, username, password, server, save_password, domain=""):
        """
        login_ctrlf12() : Enters user name, password, domain, server IP and save password for login to connect client
        Parameters: username, password, server, save_password and domain
        """
        try:
            self.webAction.input_text("Login_Email", username)
            self.webAction.input_text("Login_Password", password)
            time.sleep(2)
            self.webAction.click_element('Login_show_advanced_options')
            time.sleep(1)
            self.webAction.input_text("Login_ctrlf12_server", server)

            if save_password.lower() == "yes":
                self.webAction.select_checkbox("login_ctrlf12_save_pwd")
            # else:
            #     self.webAction.unselect_checkbox("login_ctrlf12_save_pwd")
            if domain:
                self.webAction.input_text("Login_ctrlf12_domain", domain)
            self.webAction.click_element("Login_Login_Button_server")
            log.mjLog.LogReporter("CommonFunctionality", "info", "login_ctrlf12 - Trying"
                                                                 " to login using %s and %s" % (username, password))
        except:
            log.mjLog.LogReporter("CommonFunctionality", "error", "login_ctrlf12 - Login"
                                                                  " Failed using %s and %s" % (username, password))
            raise

    def logout_if_diff_user_logged_in(self, username,option=None):
        try: 
            #import sys;import pdb;pdb.Pdb(stdout=sys.__stdout__ ).set_trace()           
            already_logged_in=True            
            windows_count=self.webAction.window_handles_count()
            # if windows count is 1, wait to see if a second window pops up.
            i=1
            while windows_count!=2:
                if i==5: break
                i=i+1
                time.sleep(1)
                windows_count=self.webAction.window_handles_count()
            if windows_count ==2:
                self.webAction.switch_to_window(1)
                already_logged_in=False
                return already_logged_in
            
            else:
                # Not required as we set allowiv=1 as part of init script.           
                #self.webAction.execute_javascript("Endo.isShowingMainAppWindow(1)")
                self.queryElement.wait_for_elem_to_be_displayed("default_people_tab",20)
                if self._browser.elements_finder("default_people_tab"):
                    # check user
                    email = self.queryElement.get_value_execute_javascript("Endo.currentUser['email']")
                    # if user matches then return
                    if email == username and option is None:                                
                        return already_logged_in
                    else:
                        # else logout and continue                                
                        self.webAction.click_element("default_user_telephony_color")
                        self.webAction.explicit_wait("default_logout")
                        self.webAction.click_element("default_logout")
                        #wait for sign in to appear and click signin
                        self.queryElement.wait_for_elem_to_be_displayed("Sign_in",20)
                        self.webAction.click_element("Sign_in")
                        console("Clicked Sign In")
                        for _ in range(15):
                            try:                    
                                self.webAction.switch_to_window(1)
                                break
                            except:
                                time.sleep(1)
                                continue  
                        
                        already_logged_in=False
                                            
        except:
            #log.mjLog.LogReporter("CommonFunctionality", "error", "logout_if_diff_user_logged_in"
            #                      " - Failed to Login to Connect Client " + str(sys.exc_info()))
            raise Exception("CommonFunctionality error logout_if_diff_user_logged_in - Failed to Login")

    def ulp_login(self, username, password,option=None):
        try :
            
            #import sys;import pdb;pdb.Pdb(stdout=sys.__stdout__ ).set_trace()
            already_logged_in = self.logout_if_diff_user_logged_in(username,option)
    
            if already_logged_in: return
                
            if option == 'verify_ulp_page':
                #pass
                self.verify_ulp_login_page()     
            if username != "" :
                self.queryElement.wait_for_elem_to_be_displayed("Login_ulp_username",20)
                if username == 'click' :
                    self.webAction.click_element("Login_ulp_username")                   
                else:
                    self.webAction.click_element("Login_ulp_username")
                    self.webAction.input_text("Login_ulp_username", username) 
                    self.webAction.click_element("Login_ulp_next_btn")
            if password == 'click' :
                self.webAction.click_element("Login_ulp_password")
               
            elif password != '' :
                self.verify_ulp_password_page(username, password)
            self.webAction.switch_to_window(0)
            
        except :
            log.mjLog.LogReporter("CommonFunctionality", "error", "ulp_login"
                                  " - Failed to Login to Connect Client " + str(sys.exc_info()))
            #self._browser._browser.switch_to_default_content()
            raise Exception("CommonFunctionality error ulp_login - Failed to Login")

    def verify_ulp_login_page(self):
        try:
            self.queryElement.wait_for_elem_to_be_displayed("Login_ulp_logo",15)
            self.assertElement.page_should_contain_element("Login_ulp_logo")
            for i in range(2):
                header_title = self.queryElement.get_text("Login_ulp_header_title") + ' ' + self.queryElement.get_text("Login_ulp_header_subtitle") 
                if header_title == 'Sign in to Mitel to continue to Mitel Connect':
                    break
                else:
                    time.sleep(1)
            else:
                err_msg = "*ERROR* expected Header title: 'Sign in to Mitel to continue to Mitel Connect' --- actual Header tile: %s" % (header_title)
                raise AssertionError(err_msg)

            username_label = self.queryElement.get_text("Login_ulp_username_label")
            if username_label != 'Enter your username':
                err_msg = "*ERROR* expected username label: Enter your username --- actual username label: %s" % (username_label)
                raise AssertionError(err_msg)

            self.assertElement.page_should_contain_element("Login_ulp_username")

            instance = self._browser._browser.switch_to_active_element()
            login_ulp_user_place_holder_text = 'Username (name@example.com)'
            active_ele = instance.get_attribute("placeholder")
            if active_ele != login_ulp_user_place_holder_text :
                err_msg = "*ERROR* expected username placeholder: %s --- actual username placeholder: %s" % (login_ulp_user_place_holder_text, active_ele)
                raise AssertionError(err_msg)

            self.assertElement.page_should_contain_element("Login_ulp_next_btn")

        except:
            log.mjLog.LogReporter("CommonFunctionality", "error", "verify_ulp_login_page"
                                  " - Failed to Verify ULP Login Page " + str(sys.exc_info()))            
            raise Exception("CommonFunctionality error verify_ulp_login_page - Failed to Verify ULP Login Page")

    def verify_ulp_password_page(self,username, password):
        try:
            self.queryElement.wait_for_elem_to_be_displayed("Login_ulp_password",20)
            time.sleep(1)
            pwd_label = self.queryElement.get_text("Login_ulp_pwd_label")
            pass_instance = self._browser.element_finder("Login_ulp_password")
            pass_text_holder = pass_instance.get_attribute("placeholder")
            console("In Password page")
            if password == 'click' :
                self.webAction.click_element("Login_ulp_password")   
            else :
                self.webAction.click_element("Login_ulp_password")
                self.webAction.input_text("Login_ulp_password", password)
            console("Entered password")
            self.assertElement.page_should_contain_element("Login_ulp_back_btn")
            self.assertElement.page_should_contain_element("Login_ulp_forget_pwd")  
            console("Before Clicking button password")    
            self.webAction.click_element("Login_ulp_pwd_btn") 
        except:
            log.mjLog.LogReporter("CommonFunctionality", "error", "verify_ulp_password_page"
                                  " - Failed to Verify ULP Password Page " + str(sys.exc_info()))
            raise Exception("CommonFunctionality error verify_ulp_password_page - Failed to Verify ULP Password Page")
    
    def login(self, username, password, server_address):
        '''
            enter user name and password and click on login
        '''
        try:
            log.mjLog.LogReporter("CommonFunctionality", "info", "Login - Trying to login " \
                                                                 "using %s and %s" % (username, password))

            self.webAction.clear_input_text("Login_Email")
            self.webAction.double_click_element("Login_Email")
            self.webAction.input_text_basic("Login_Email", username)
            self.webAction.double_click_element("Login_Password")
            self.webAction.input_text_basic("Login_Password", password)
            self.webAction.explicit_wait('Login_show_advanced_options')
            self.webAction.click_element('Login_show_advanced_options')
            self.webAction.explicit_wait('Login_ctrlf12_server')
            self.webAction.double_click_element("Login_ctrlf12_server")
            self.webAction.input_text_basic("Login_ctrlf12_server", server_address)
            
            #click the login button
            self.webAction.click_element("Login_Login")
            time.sleep(2)
            log.mjLog.LogReporter("CommonFunctionality", "info", "login- Trying to login " \
                                                                 "using %s and %s" % (username, password))
        except:
            log.mjLog.LogReporter("CommonFunctionality", "error", "login - LoginFailed ",
                                  "using %s and %s" % (username, password))
            raise

            
    def ulp_ad_user_login(self,username,password,second_time='false'):
        """
        This API will verify AD user login Page
        """
        try:
            self.logout_if_diff_user_logged_in(username,"ad_user")
            ###            
            if username != "" :                     # -- if username is empty -- #
                self.queryElement.wait_for_elem_to_be_displayed("Login_ulp_username",20)
                if username == 'click' :
                    self.webAction.click_element("Login_ulp_username")
                else:
                    self.webAction.click_element("Login_ulp_username")
                    self.webAction.input_text("Login_ulp_username", username) 
                    self.webAction.click_element("Login_ulp_next_btn")
                    
            #-------------------------Verify Single login button appears---------
            self.queryElement.wait_for_elem_to_be_displayed("login_ad_user_single_sign",20)
            self.webAction.click_element("login_ad_user_single_sign")
            
            if second_time == 'false':                
                self.outlook_page_login(username,password)  
            self.webAction.switch_to_window(0)
            self.queryElement.wait_for_elem_to_be_displayed("default_user_telephony_color") 
            
        except:
            traceback.print_exc(file=sys.stdout)
            raise Exception("CommonFunctionality error ulp_ad_user_login - Failed to Verify AD user Login Page")

    def outlook_page_login(self, username, password):
        """API specifies to login to outllok page
        """
        try:
            #----------------------Verifies Outlook Login---------
            #self.queryElement.wait_for_elem_to_be_displayed("login_ad_microsoft_username",30)
            #self.webAction.click_element("login_ad_microsoft_username")
            #self.webAction.input_text("login_ad_microsoft_username",username)
            #self.queryElement.wait_for_elem_to_be_displayed("login_ad_microsoft_next_btn")
            #self.webAction.click_element("login_ad_microsoft_next_btn")
            #time.sleep(2)
            self.queryElement.wait_for_elem_to_be_displayed("login_ad_microsoft_pwd_label",20)
            
            self.queryElement.wait_for_elem_to_be_displayed("login_ad_microsoft_pwd") 
            self.webAction.click_element("login_ad_microsoft_pwd")
            self.webAction.input_text("login_ad_microsoft_pwd", password) 
            self.queryElement.wait_for_elem_to_be_displayed("login_ad_pwd_next_btn",20)
            self.webAction.click_element("login_ad_pwd_next_btn")
            
            #------------------------Click on No button to reduced no of times login-----
            signed_in_no_btn = self.queryElement.wait_for_elem_to_be_displayed("login_ad_signedin_no_btn",5)
            if signed_in_no_btn:
                self.webAction.click_element("login_ad_signedin_no_btn")
        except:
            traceback.print_exc(file=sys.stdout)
            raise Exception("CommonFunctionality error outlook_page_login - Failed to login using outlook page")

    def verify_multiple_acc_message(self, params):
        try:
            #import sys;import pdb;pdb.Pdb(stdout=sys.__stdout__ ).set_trace()
            self.webAction.switch_to_window(1)  
            if 'multiple_account_info' in params.keys():
                multiple_acc_text = self.queryElement.get_text("login_multiple_acc")
                if multiple_acc_text != params['multiple_account_info']:
                    err_msg = "*ERROR* expected multiple_acc Label: %s --- actual multiple_acc label: %s" % (multiple_acc_text, params['multiple_account_info'])
                    raise AssertionError(err_msg)

            if 'enter_account_id' in params.keys():
                self.webAction.input_text("login_input_multiple_accid", params['enter_account_id'])
                self.webAction.click_element("Login_ulp_next_btn")
            
            if 'select_from_dropdown' in params.keys():
                self.webAction.click_element("login_input_multiple_button")
                self.webAction.select_from_dropdown_using_text("login_input_multiple_dropdown", "SIT")
                self.webAction.click_element("Login_ulp_next_btn")
        except:
            traceback.print_exc(file=sys.stdout)
            raise Exception("CommonFunctionality error verify_multiple_acc_message - Failed to Verify Password Success Page")

    def verify_login_error_message(self, error_status):
        try:
            for _ in range(10):
                try:
                    self.webAction.switch_to_window(1)
                    error = self._browser._browser.execute_script("return $('.error-block')[0].innerText")
                    if error: break
                except:            
                    pass
                time.sleep(2)  
            if error_status != "false" :
                if error_status == login_ulp_error_msg :                    
                    if error_status not in error :
                        err_msg = "*ERROR* expected Error msg: %s --- actual Error msg: %s" % (error_status, error)
                        raise AssertionError(err_msg)            
        except:
            traceback.print_exc(file=sys.stdout)
            raise
            
    def clear_ulp_credentials(self, credential):
        try:
            self.webAction.switch_to_window(1)  
            if credential == 'username' :
                self.webAction.click_element("Login_ulp_username")
                self.webAction.clear_input_text_new()
                #time.sleep(1)
                username_instance = self._browser.element_finder("Login_ulp_username")
                username_text_holder = username_instance.get_attribute("placeholder")
                if username_text_holder != login_ulp_user_place_holder_text :
                    err_msg = "*ERROR* expected username placeholder: %s --- actual username placeholder: %s" % (login_ulp_user_place_holder_text, username_text_holder)
                    raise err_msg
            elif credential == 'password' :
                self.webAction.click_element("Login_ulp_password")
                self.webAction.clear_input_text_new()
                time.sleep(1)
                pass_instance = self._browser.element_finder("Login_ulp_password")
                pass_text_holder = pass_instance.get_attribute("placeholder")
                if pass_text_holder != login_password_text_place_holder :
                    err_msg = "*ERROR* expected username placeholder: %s --- actual username placeholder: %s" % (login_password_text_place_holder, pass_text_holder)
                    raise err_msg
            #self._browser._browser.switch_to_default_content()
        except:
            raise
            
    def verify_ulp_forget_password_page(self, params):
        '''
        This API will verify the ULP Forget password Page
        '''
        try:
            self.webAction.switch_to_window(1)  
            self.queryElement.wait_for_elem_to_be_displayed("Login_ulp_forget_pwd",5)
            if 'click' in params.keys():
                self.webAction.click_element("Login_ulp_forget_pwd")

            if 'verify_forget_pwd_page' in params.keys():
                forget_pwd_label = self.queryElement.get_text("Login_ulp_header_title")
                if forget_pwd_label != login_forget_pwd_label:
                    err_msg = "*ERROR* expected forget_pwd Label: %s --- actual forget_pwd label: %s" % (login_forget_pwd_label, forget_pwd_label)
                    raise AssertionError(err_msg)

                enter_mail_label = self.queryElement.get_text("Login_ulp_enter_email_label")
                if enter_mail_label != login_enter_mail_label:
                    err_msg = "*ERROR* expected enter_mail Label: %s --- actual enter_mail label: %s" % (login_enter_mail_label, enter_mail_label)
                    raise AssertionError(err_msg)

                hint_text = self.queryElement.get_text("Login_ulp_hint_text")
                if hint_text != login_hint_text:
                    err_msg = "*ERROR* expected hint_text Label: %s --- actual hint_text label: %s" % (login_hint_text, login_hint_text)
                    raise AssertionError(err_msg)

                self.assertElement.page_should_contain_element("login_forget_pwd_inputbox")

                self.assertElement.page_should_contain_element("login_page_btn")
                login_btn_label = self.queryElement.get_text("login_page_btn")
                if login_btn_label != login_btn_text:
                    err_msg = "*ERROR* expected login button Label: %s --- actual login button label: %s" % (login_btn_text, login_btn_label)
                    raise AssertionError(err_msg)

                self.assertElement.page_should_contain_element("Login_ulp_next_btn")
                next_btn_label = self.queryElement.get_text("Login_ulp_next_btn")
                if next_btn_label != login_next_btn_text:
                    err_msg = "*ERROR* expected next button Label: %s --- actual next button label: %s" % (login_next_btn_text, next_btn_label)
                    raise AssertionError(err_msg)

            if 'username' in params.keys():
                self.webAction.click_element("Login_ulp_next_btn")

            else:
                raise AssertionError("Forget password link not found")
                
        except:
            traceback.print_exc(file=sys.stdout)
            raise Exception("CommonFunctionality error verify_ulp_forget_password_page - Failed to Verify Forget Password")

    def ulp_send_link_page(self, params):
        '''
        This API verify SEND LINk Page
        '''
        
        console("INSIDE") 
        try:
            for i in range(10):
                try:
                    self.webAction.switch_to_window(1)  
                    self.assertElement.page_should_contain_text("Enter Code")
                    break    
                except:
                    if i==9: raise AssertionError("Send Link confirmation page not seen")
                    time.sleep(1)
            if 'send_link_page' in params.keys():
                console("Inside IF send_link_page\n")
                forget_pwd_label = self.queryElement.get_text("Login_ulp_header_title")
                if forget_pwd_label != login_forget_pwd_label:
                    err_msg = "*ERROR* expected forget password Label: %s --- actual forget password label: %s" % (login_forget_pwd_label, forget_pwd_label)
                    raise AssertionError(err_msg)

                instruction_label = self.queryElement.get_text("Login_ulp_enter_email_label")                
                if instruction_label != login_instruction_label:
                    err_msg = "*ERROR* expected Instruction Label: %s --- actual Instruction label: %s" % (login_instruction_label, instruction_label)
                    raise AssertionError(err_msg)

                instruction_hint_text = self.queryElement.get_text("Login_ulp_hint_text")
                if instruction_hint_text != login_instruction_hint_text:
                    err_msg = "*ERROR* expected Instruction hint Label: %s --- actual Instruction hint label: %s" % (login_instruction_hint_text, instruction_hint_text)
                    raise AssertionError(err_msg)

                self.assertElement.page_should_contain_element("Login_ulp_next_btn")
                code_text = self.queryElement.get_text("Login_ulp_next_btn")

                if code_text != login_enter_code:
                    err_msg = "*ERROR* expected enter code text Label: %s --- actual enter code text label: %s" % (login_enter_code, code_text)
                    raise AssertionError(err_msg)

                self.assertElement.page_should_contain_element("login_resend_mail_link")

                resend_mail = self.queryElement.get_text("login_resend_mail_link")
                if resend_mail != login_resend_mail:
                    err_msg = "*ERROR* expected resend mail Label: %s --- actual resend mail label: %s" % (login_resend_mail, resend_mail)
                    raise AssertionError(err_msg)

                instruction_end = self.queryElement.get_text("login_instruction_end")
                
                if instruction_end != login_instruction_end:
                    err_msg = "*ERROR* expected instruction end label: %s --- actual instruction end label: %s" % (login_resend_mail, resend_mail)
                    raise AssertionError(err_msg)

            if 'resend_email' in params.keys():
                self.webAction.click_element("login_resend_mail_link")

            if 'enter_code' in params.keys():
                self.webAction.click_element("Login_ulp_next_btn")
            
        except:
            traceback.print_exc(file=sys.stdout)
            raise Exception("CommonFunctionality error ulp_send_link_page - Failed to Verify Send Link Confirmation Page")
            
    def ulp_confirm_code_page(self, params):
        '''
        This API verify confirm code page
        '''
        try:           
            self.webAction.switch_to_window(1)  
            if 'confirm_code_page' in params.keys():
                forget_pwd_label = self.queryElement.get_text("Login_ulp_header_title")
                if forget_pwd_label != login_forget_pwd_label:
                    err_msg = "*ERROR* expected forget password label: %s --- actual forget password label: %s" % (login_forget_pwd_label, forget_pwd_label)
                    raise AssertionError(err_msg)

                confirmation_label = self.queryElement.get_text("Login_ulp_enter_email_label")
                if confirmation_label != login_confirmation_label:
                    err_msg = "*ERROR* expected confirmation label: %s --- actual confirmation label: %s" % (login_confirmation_label, confirmation_label)
                    raise AssertionError(err_msg)

                confirm_mail = self.queryElement.get_text("Login_ulp_hint_text")
                if confirm_mail != login_confirm_mail:
                    err_msg = "*ERROR* expected confirmation mail label: %s --- actual confirmation mail label: %s" % (login_confirm_mail, confirm_mail)
                    raise AssertionError(err_msg)

                self.assertElement.page_should_contain_element("login_confirm_code_inputbox")

                self.assertElement.page_should_contain_element("login_resend_code")
                resend_code_label = self.queryElement.get_text("login_resend_code")
                if resend_code_label != login_resend_code_text:
                    err_msg = "*ERROR* expected resend code label: %s --- actual resend code label: %s" % (login_resend_code_text, resend_code_label)
                    raise AssertionError(err_msg)

                self.assertElement.page_should_contain_element("login_submit_btn")
                submit_btn = self.queryElement.get_text("login_submit_btn")
                if submit_btn != login_submit_btn_text:
                    err_msg = "*ERROR* expected submit button label: %s --- actual submit button label: %s" % (login_submit_btn_text, submit_btn)
                    raise AssertionError(err_msg)

            if 'input_code' in params.keys():
                self.webAction.input_text("login_confirm_code_inputbox", params['input_code'])
                self.webAction.click_element("login_submit_btn")
        except:
            traceback.print_exc(file=sys.stdout)
            raise Exception("CommonFunctionality error ulp_confirm_code_page - Failed to Verify Confirmation Code Page" + err_msg)

    def ulp_set_new_pwd_page(self, params):
        '''
        This API verify set new password
        '''
        try:
            self.webAction.switch_to_window(1)  
            self.queryElement.wait_for_elem_to_be_displayed("login_enter_new_pwd",20)
            if 'set_new_pwd_page' in params.keys():
                set_new_pwd_label = self.queryElement.get_text("Login_ulp_header_title")
                if set_new_pwd_label != login_set_new_pwd_label:
                    err_msg = "*ERROR* expected set new password label: %s --- actual set new password label: %s" % (login_set_new_pwd_label, set_new_pwd_label)
                    raise AssertionError(err_msg)

                enter_new_pwd_label = self.queryElement.get_text("login_enter_new_pwd")
                if enter_new_pwd_label != login_enter_new_pwd_label:
                    err_msg = "*ERROR* expected enter new password label: %s --- actual enter new password label: %s" % (login_set_new_pwd_label, set_new_pwd_label)
                    raise AssertionError(err_msg)

                self.assertElement.page_should_contain_element("login_new_pwd_input")
                self.assertElement.page_should_contain_element("login_confirm_pwd_input")

                pwd_requirement = self._browser._browser.execute_script("return $('.password-rules')[0].innerText")
                self.assertElement.page_should_contain_element("Login_ulp_next_btn")

            if 'enter_new_pwd' in params.keys():
                self.webAction.input_text("login_new_pwd_input", params['enter_new_pwd'])
                self.webAction.input_text("login_confirm_pwd_input", params['enter_new_pwd'])
                self.webAction.click_element("Login_ulp_next_btn")
            self.webAction.switch_to_window(0)  
        except:
            traceback.print_exc(file=sys.stdout)
            raise Exception("CommonFunctionality error ulp_set_new_pwd_page - Failed to Verify Confirmation Code Page")

